**********
Generators
**********

.. toctree::
   :maxdepth: 1

   basic_3pt_arc
   basic_spline
   quad_spline
   box_mk2
   bricks
   circle
   cylinder_mk2
   image
   line_mk4
   ngon
   plane_mk3
   random_vector_mk3
   sphere
   icosphere
   suzanne
   torus_mk2
   formula_shape
   segment
   cricket
