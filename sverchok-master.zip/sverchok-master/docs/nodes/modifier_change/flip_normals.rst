flip normals
============

This node offers the usual normal recalculation features, but when all faces are disjoint islands this node will attempt to flip all faces towards the same direction. 

In the scenario where you present the node with only disjoint faces, it expects that you are passing it faces on the same plane (like X,Y).