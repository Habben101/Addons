**********
Dictionary
**********

.. toctree::
   :maxdepth: 1

   dictionary_in
   dictionary_out