*************
List Mutators
*************

.. toctree::
   :maxdepth: 1

   modifier
   unique_items
   polygon_sort
   combinatorics
   filter_empty_lists
   find_closest
   multi_cache
