*****
Logic
*****

.. toctree::
   :maxdepth: 1

   logic_node
   neuro_elman
   evolver
   genes_holder
   switch_MK2
   input_switch_mod
   custom_switcher
   range_switch
   loop_in
   loop_out
