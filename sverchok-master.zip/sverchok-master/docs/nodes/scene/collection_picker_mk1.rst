Collection Picker mk1
=====================

this node currently has a very simple function, output the objects associated with a collection. This will not included nested objects yet.
