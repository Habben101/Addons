selection grabber lite
======================

This node expects you to point it to an object. The object can be in edit mode. Depending on the connected outputs, this node will output lists of masks (booleans) into the nodetree that represent the lists of selected Verts/Edges/Faces. 

This is useful for nodes that have mask sockets expecting True/False like input.

