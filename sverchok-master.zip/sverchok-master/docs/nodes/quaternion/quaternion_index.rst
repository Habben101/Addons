**********
Quaternion
**********

.. toctree::
   :maxdepth: 1

   quaternion_in_mk2
   quaternion_out_mk2
   quaternion_math
   rotation_difference
