**************
Data structure
**************


.. toctree::
    :maxdepth: 1

    geometry
    curves
    surfaces
    nurbs
    fields
    solids