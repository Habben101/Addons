************************
Contributing to sverchok
************************

.. toctree::
   :maxdepth: 1

   contribute_small_things
   contribute_general
   add_new_node
   testing