# ifc5d

Ifc5D is a collection of utilities of manipulating cost-related data to and from
formats, reports, and optimisation engines.

Currently supported:

 - CSV to IFC

Planned (would you like to contribute? Please reach out!):

 - IFC to CSV
 - IFC to PDF
 - IFC to ODS
 - IFC to XLSX
 - ODS to CSV
 - XLSX to CSV
 - IFC to Graph
