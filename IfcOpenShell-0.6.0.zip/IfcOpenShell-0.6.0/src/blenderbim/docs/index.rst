IfcOpenShell Documentation
==========================

.. toctree::
   :maxdepth: 1
   :caption: Contents:

   ifcopenshell
   ifcopenshell-python
   ifcconvert
   blenderbim
   bimtester
   ifcdiff
   ifcclash
   ifccobie
   ifcmax
   ifcsverchok
   bimserver-plugin


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
