IfcOpenShell
============

This documentation is free software! You are free to contribute and help write
this document.

.. toctree::
   :maxdepth: 1
   :caption: Contents:

Indices and tables
------------------

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
