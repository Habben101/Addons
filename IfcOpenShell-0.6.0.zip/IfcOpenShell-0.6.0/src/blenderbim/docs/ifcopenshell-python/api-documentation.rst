API Documentation
=================

.. automodule:: ifcopenshell.entity_instance
   :members:

.. automodule:: ifcopenshell.file
   :members:

.. automodule:: ifcopenshell.guid
   :members:


.. automodule:: ifcopenshell.template
   :members:

.. automodule:: ifcopenshell.validate
   :members:

.. automodule:: ifcopenshell.ids
   :members:
