Quickstart
==========

For starters, you can read `Using IfcOpenShell to parse IFC files with Python
<https://thinkmoult.com/using-ifcopenshell-parse-ifc-files-python.html>`_
