# ifcopenshell-python

Python bindings, utility functions, and high-level API for IfcOpenShell.
