#!/usr/bin/env python3

from bimtester.guiwidget import run


run()
