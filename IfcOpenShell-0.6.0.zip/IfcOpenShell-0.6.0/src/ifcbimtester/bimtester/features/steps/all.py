use_step_matcher("parse")
from bimtester.features.steps.classification import en

use_step_matcher("parse")
from bimtester.features.steps.element_classes import en

use_step_matcher("parse")
from bimtester.features.steps.geocoding import en

use_step_matcher("parse")
from bimtester.features.steps.geolocation import en

use_step_matcher("parse")
from bimtester.features.steps.geometric_detail import en

use_step_matcher("parse")
from bimtester.features.steps.model_federation import en

use_step_matcher("parse")
from bimtester.features.steps.project_setup import de, en, fr, it, nl

use_step_matcher("parse")
from bimtester.features.steps.aggregation import en

use_step_matcher("parse")
from bimtester.features.steps.attributes_psets import en, de
