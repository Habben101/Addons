class IfcStore:
    path = ""
    file = None
    bookmarks = {}
