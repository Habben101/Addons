# ifc4d

Ifc4D contains a series of utilities for converting to and from various 4D software. Currently supported:

 - Microsoft Project to IFC
 - Oracle Primavera 6 (P6) to IFC

Planned (would you like to contribute? Please reach out!):

 - IFC to Microsoft Project
 - IFC to Oracle Primavera 6 (P6)
 - Asta Powerproject to IFC
 - IFC to Asta Powerproject
 - LibreProject to IFC
 - IFC to LibreProject
 - IFC to Gantt
