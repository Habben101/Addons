# IfcFM

IfcFM is a library that handles the extraction and analysis of IFC data for the
purposes of facility management.

It is currently a prototype and will supersede the IfcCOBie library. It is
planned to support workflows related to the old COBie standard, as well as
upcoming IFC Facility Management related MVDs.
