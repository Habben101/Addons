IfcOpenShell
============

.. toctree::
   :maxdepth: 3

   rst_files/library_root


* `ifcopenshell-python documentation <python/html/index.html>`_