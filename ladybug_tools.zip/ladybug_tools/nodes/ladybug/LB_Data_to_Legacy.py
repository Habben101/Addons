import bpy
import ladybug_tools.helper
from bpy.props import StringProperty
from sverchok.node_tree import SverchCustomTreeNode
from sverchok.data_structure import updateNode, zip_long_repeat

ghenv = ladybug_tools.helper.ghenv

class SvToLegacy(bpy.types.Node, SverchCustomTreeNode):
    bl_idname = 'SvToLegacy'
    bl_label = 'LB Data to Legacy'
    sv_icon = 'LB_TOLEGACY'
    sv__data: StringProperty(name='_data', update=updateNode, description='A Ladybug DataCollection object.')

    def sv_init(self, context):
        self.width *= 1.3
        input_node = self.inputs.new('SvLBSocket', '_data')
        input_node.prop_name = 'sv__data'
        input_node.tooltip = 'A Ladybug DataCollection object.'
        output_node = self.outputs.new('SvLBSocket', 'data')
        output_node.tooltip = 'A Ladybug Legacy list with meatadata and values.'

    def draw_buttons(self, context, layout):
        op = layout.operator('node.sv_lb_socket_name', text='', icon='QUESTION', emboss=False).tooltip = 'Convert a Ladybug DataCollection into its Ladybug Legacy format. - Note that this component is intended to be temporary as people transition from Ladybug Legacy to Ladybug[+]. -'

    def process(self):
        if not any(socket.is_linked for socket in self.outputs):
            return

        self.sv_output_names = ['data']
        for name in self.sv_output_names:
            setattr(self, '{}_out'.format(name), [])
        self.sv_input_names = ['_data']
        self.sv_input_types = ['System.Object']
        self.sv_input_defaults = [None]
        self.sv_input_access = ['item']
        sv_inputs_nested = []
        for name in self.sv_input_names:
            sv_inputs_nested.append(self.inputs[name].sv_get())
        for sv_input_nested in zip_long_repeat(*sv_inputs_nested):
            for sv_input in zip_long_repeat(*sv_input_nested):
                sv_input = list(sv_input)
                for i, value in enumerate(sv_input):
                    if self.sv_input_access[i] == 'list':
                        if isinstance(value, (list, tuple)):
                            values = value
                        else:
                            values = [value]
                        value = [self.sv_cast(v, self.sv_input_types[i], self.sv_input_defaults[i]) for v in values]
                        if value == [None]:
                            value = []
                        sv_input[i] = value
                    else:
                        sv_input[i] = self.sv_cast(value, self.sv_input_types[i], self.sv_input_defaults[i])
                self.process_ladybug(*sv_input)
        for name in self.sv_output_names:
            value = getattr(self, '{}_out'.format(name))
            # Not sure if this hack is correct, will find out when more nodes are generated
            #if len(value) == 0 or not isinstance(value[0], (list, tuple)):
            #    value = [value]
            self.outputs[name].sv_set(value)

    def sv_cast(self, value, data_type, default):
        result = default if isinstance(value, str) and value == '' else value
        if result is None and data_type == 'bool':
            return False
        elif result is not None and data_type == 'bool':
            if result == 'True' or result == '1':
                return True
            elif result == 'False' or result == '0':
                return False
            return bool(result)
        elif result is not None and data_type == 'int':
            return int(result)
        elif result is not None and data_type == 'double':
            return float(result)
        return result

    def process_ladybug(self, _data):

        try:
            from ladybug.datacollection import HourlyContinuousCollection, \
                MonthlyCollection, DailyCollection, MonthlyPerHourCollection
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug:\n\t{}'.format(e))
        
        try:
            from ladybug_tools.sverchok import all_required_inputs
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug_tools:\n\t{}'.format(e))
        
        # base header list
        head = ['key:location/dataType/units/frequency/startsAt/endsAt',
                'Unkown Location']
        
        
        if all_required_inputs(ghenv.Component):
            # add the location, data type, and units
            meta_data = _data.header.metadata
            if 'city' in meta_data:
                head[1] = meta_data['city']
            if 'type' in meta_data:
                if 'Zone' in meta_data:
                    head.append('{} for {}'.format(meta_data['type'], meta_data['Zone']))
                elif 'System' in meta_data:
                    head.append('{} for {}'.format(meta_data['type'], meta_data['System']))
                else:
                    head.append(meta_data['type'])
            else:
                head.append(str(_data.header.data_type))
            head.append(_data.header.unit)
        
            # add the time interval
            a_per = _data.header.analysis_period
            if isinstance(_data, HourlyContinuousCollection):
                if a_per.timestep == 1:
                    head.append('Hourly')
                else:
                    head.append('Timestep')
            elif isinstance(_data, MonthlyCollection):
                head.append('Monthly')
            elif isinstance(_data, DailyCollection):
                head.append('Daily')
            elif isinstance(_data, MonthlyPerHourCollection):
                head.append('Monthly-> averaged for each hour')
            else:
                raise TypeError(
                    '_data must be a Data Collection. Got {}.'.format(type(_data)))
        
            # add the analysis period
            head.append((a_per.st_month, a_per.st_day, a_per.st_hour + 1))
            head.append((a_per.end_month, a_per.end_day, a_per.end_hour + 1))
        
            # return the data
            data = head + list(_data.values)
        

        for name in self.sv_output_names:
            if name in locals():
                getattr(self, '{}_out'.format(name)).append([locals()[name]])


def register():
    bpy.utils.register_class(SvToLegacy)

def unregister():
    bpy.utils.unregister_class(SvToLegacy)
