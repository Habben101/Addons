import bpy
import ladybug_tools.helper
from bpy.props import StringProperty
from sverchok.node_tree import SverchCustomTreeNode
from sverchok.data_structure import updateNode, zip_long_repeat

ghenv = ladybug_tools.helper.ghenv

class SvSkyMatrix(bpy.types.Node, SverchCustomTreeNode):
    bl_idname = 'SvSkyMatrix'
    bl_label = 'LB Cumulative Sky Matrix'
    sv_icon = 'LB_SKYMATRIX'
    sv_north_: StringProperty(name='north_', update=updateNode, description='A number between -360 and 360 for the counterclockwise difference between the North and the positive Y-axis in degrees. 90 is West and 270 is East. This can also be Vector for the direction to North. (Default: 0)')
    sv__location: StringProperty(name='_location', update=updateNode, description='A ladybug Location that has been output from the "LB Import EPW" component or the "LB Construct Location" component.')
    sv__direct_rad: StringProperty(name='_direct_rad', update=updateNode, description='An annual hourly DataCollection of Direct Normal Radiation such as that which is output from the "LB Import EPW" component or the "LB Import STAT" component.')
    sv__diffuse_rad: StringProperty(name='_diffuse_rad', update=updateNode, description='An annual hourly DataCollection of Diffuse Horizontal Radiation such as that which is output from the "LB Import EPW" component or the "LB Import STAT" component.')
    sv__hoys_: StringProperty(name='_hoys_', update=updateNode, description='A number or list of numbers between 0 and 8760 that respresent the hour(s) of the year for which to generate the sky matrix. The "LB Calculate HOY" component can output this number given a month, day and hour. The "LB Analysis Period" component can output a list of HOYs within a certain hour or date range. By default, the matrix will be for the entire year.')
    sv_high_density_: StringProperty(name='high_density_', update=updateNode, description='A Boolean to indicate whether the higher-density Reinhart sky matrix should be generated (True), which has roughly 4 times the sky patches as the (default) original Tregenza sky (False). Note that, while the Reinhart sky has a higher resolution and is more accurate, it will result in considerably longer calculation time for incident radiation studies. The difference in sky resolution can be observed with the (Default: False).')
    sv__ground_ref_: StringProperty(name='_ground_ref_', update=updateNode, description='A number between 0 and 1 to note the average ground reflectance that is associated with the sky matrix. (Default: 0.2).')
    sv__folder_: StringProperty(name='_folder_', update=updateNode, description='The folder in which the Radiance commands are executed to produce the sky matrix. If None, it will be written to Ladybug\'s default EPW folder.')

    def sv_init(self, context):
        self.width *= 1.3
        input_node = self.inputs.new('SvLBSocket', 'north_')
        input_node.prop_name = 'sv_north_'
        input_node.tooltip = 'A number between -360 and 360 for the counterclockwise difference between the North and the positive Y-axis in degrees. 90 is West and 270 is East. This can also be Vector for the direction to North. (Default: 0)'
        input_node = self.inputs.new('SvLBSocket', '_location')
        input_node.prop_name = 'sv__location'
        input_node.tooltip = 'A ladybug Location that has been output from the "LB Import EPW" component or the "LB Construct Location" component.'
        input_node = self.inputs.new('SvLBSocket', '_direct_rad')
        input_node.prop_name = 'sv__direct_rad'
        input_node.tooltip = 'An annual hourly DataCollection of Direct Normal Radiation such as that which is output from the "LB Import EPW" component or the "LB Import STAT" component.'
        input_node = self.inputs.new('SvLBSocket', '_diffuse_rad')
        input_node.prop_name = 'sv__diffuse_rad'
        input_node.tooltip = 'An annual hourly DataCollection of Diffuse Horizontal Radiation such as that which is output from the "LB Import EPW" component or the "LB Import STAT" component.'
        input_node = self.inputs.new('SvLBSocket', '_hoys_')
        input_node.prop_name = 'sv__hoys_'
        input_node.tooltip = 'A number or list of numbers between 0 and 8760 that respresent the hour(s) of the year for which to generate the sky matrix. The "LB Calculate HOY" component can output this number given a month, day and hour. The "LB Analysis Period" component can output a list of HOYs within a certain hour or date range. By default, the matrix will be for the entire year.'
        input_node = self.inputs.new('SvLBSocket', 'high_density_')
        input_node.prop_name = 'sv_high_density_'
        input_node.tooltip = 'A Boolean to indicate whether the higher-density Reinhart sky matrix should be generated (True), which has roughly 4 times the sky patches as the (default) original Tregenza sky (False). Note that, while the Reinhart sky has a higher resolution and is more accurate, it will result in considerably longer calculation time for incident radiation studies. The difference in sky resolution can be observed with the (Default: False).'
        input_node = self.inputs.new('SvLBSocket', '_ground_ref_')
        input_node.prop_name = 'sv__ground_ref_'
        input_node.tooltip = 'A number between 0 and 1 to note the average ground reflectance that is associated with the sky matrix. (Default: 0.2).'
        input_node = self.inputs.new('SvLBSocket', '_folder_')
        input_node.prop_name = 'sv__folder_'
        input_node.tooltip = 'The folder in which the Radiance commands are executed to produce the sky matrix. If None, it will be written to Ladybug\'s default EPW folder.'
        output_node = self.outputs.new('SvLBSocket', 'sky_mtx')
        output_node.tooltip = 'A sky matrix object containing the radiation coming from each patch of the sky. This can be used for a radiation study, a radition rose, or a sky dome visualization. It can also be deconstructed into its individual values with the "LB Deconstruct Matrix" component.'

    def draw_buttons(self, context, layout):
        op = layout.operator('node.sv_lb_socket_name', text='', icon='QUESTION', emboss=False).tooltip = 'Get a matrix containing radiation values from each patch of a sky dome. _ Creating this matrix is a necessary pre-step before doing incident radiation analysis with Rhino geometry or generating a radiation rose. _ This component uses Radiance\'s gendaymtx function to calculate the radiation for each patch of the sky. Gendaymtx is written by Ian Ashdown and Greg Ward. Morere information can be found in Radiance manual at: http://www.radiance-online.org/learning/documentation/manual-pages/pdfs/gendaymtx.pdf -'

    def process(self):
        if not any(socket.is_linked for socket in self.outputs):
            return

        self.sv_output_names = ['sky_mtx']
        for name in self.sv_output_names:
            setattr(self, '{}_out'.format(name), [])
        self.sv_input_names = ['north_', '_location', '_direct_rad', '_diffuse_rad', '_hoys_', 'high_density_', '_ground_ref_', '_folder_']
        self.sv_input_types = ['System.Object', 'System.Object', 'System.Object', 'System.Object', 'double', 'bool', 'double', 'string']
        self.sv_input_defaults = [None, None, None, None, None, None, None, None]
        self.sv_input_access = ['item', 'item', 'item', 'item', 'list', 'item', 'item', 'item']
        sv_inputs_nested = []
        for name in self.sv_input_names:
            sv_inputs_nested.append(self.inputs[name].sv_get())
        for sv_input_nested in zip_long_repeat(*sv_inputs_nested):
            for sv_input in zip_long_repeat(*sv_input_nested):
                sv_input = list(sv_input)
                for i, value in enumerate(sv_input):
                    if self.sv_input_access[i] == 'list':
                        if isinstance(value, (list, tuple)):
                            values = value
                        else:
                            values = [value]
                        value = [self.sv_cast(v, self.sv_input_types[i], self.sv_input_defaults[i]) for v in values]
                        if value == [None]:
                            value = []
                        sv_input[i] = value
                    else:
                        sv_input[i] = self.sv_cast(value, self.sv_input_types[i], self.sv_input_defaults[i])
                self.process_ladybug(*sv_input)
        for name in self.sv_output_names:
            value = getattr(self, '{}_out'.format(name))
            # Not sure if this hack is correct, will find out when more nodes are generated
            #if len(value) == 0 or not isinstance(value[0], (list, tuple)):
            #    value = [value]
            self.outputs[name].sv_set(value)

    def sv_cast(self, value, data_type, default):
        result = default if isinstance(value, str) and value == '' else value
        if result is None and data_type == 'bool':
            return False
        elif result is not None and data_type == 'bool':
            if result == 'True' or result == '1':
                return True
            elif result == 'False' or result == '0':
                return False
            return bool(result)
        elif result is not None and data_type == 'int':
            return int(result)
        elif result is not None and data_type == 'double':
            return float(result)
        return result

    def process_ladybug(self, north_, _location, _direct_rad, _diffuse_rad, _hoys_, high_density_, _ground_ref_, _folder_):

        import os
        import subprocess
        import math
        
        try:
            from ladybug_geometry.geometry2d.pointvector import Vector2D
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug_geometry:\n\t{}'.format(e))
        
        try:
            from ladybug.wea import Wea
            from ladybug.viewsphere import view_sphere
            from ladybug.dt import DateTime
            from ladybug.config import folders as lb_folders
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug:\n\t{}'.format(e))
        
        try:
            from ladybug_tools.togeometry import to_vector2d
            from ladybug_tools.sverchok import all_required_inputs, objectify_output
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug_tools:\n\t{}'.format(e))
        
        
        # TODO: Remove dependency on honeybee + Radiance after genskymtx is in its own LB extension
        try:
            from honeybee_radiance.config import folders as hb_folders
            from lbt_recipes.version import check_radiance_date
        except ImportError as e:
            raise ImportError('\nFailed to import honeybee_radiance:\n\t{}'.format(e))
        
        # check the istalled Radiance date and get the path to the gemdaymtx executable
        check_radiance_date()
        gendaymtx_exe = os.path.join(hb_folders.radbin_path, 'gendaymtx.exe') if \
            os.name == 'nt' else os.path.join(hb_folders.radbin_path, 'gendaymtx')
        
        
        # constants for converting RGB values output by gendaymtx to broadband radiation
        PATCHES_PER_ROW = {
            1: view_sphere.TREGENZA_PATCHES_PER_ROW + (1,),
            2: view_sphere.REINHART_PATCHES_PER_ROW + (1,)
        }
        PATCH_ROW_COEFF = {
            1 : view_sphere.TREGENZA_COEFFICIENTS,
            2: view_sphere.REINHART_COEFFICIENTS
        }
        
        
        def broadband_radiation(patch_row_str, row_number, wea_duration, sky_density=1):
            """Parse a row of gendaymtx RGB patch data in W/sr/m2 to radiation in kWh/m2.
        
            This includes aplying broadband weighting to the RGB bands, multiplication
            by the steradians of each patch, and multiplying by the duration of time that
            they sky matrix represents in hours.
        
            Args:
                patch_row_str: Text string for a single row of RGB patch data.
                row_number: Interger for the row number that the patch corresponds to.
                sky_density: Integer (either 1 or 2) for the density.
                wea_duration: Number for the duration of the Wea in hours. This is used
                    to convert between the average value output by the command and the
                    cumulative value that is needed for all ladybug analyses.
            """
            R, G, B = patch_row_str.split(' ')
            weight_val = 0.265074126 * float(R) + 0.670114631 * float(G) + 0.064811243 * float(B)
            return weight_val * PATCH_ROW_COEFF[sky_density][row_number] * wea_duration / 1000
        
        
        def parse_mtx_data(data_str, wea_duration, sky_density=1):
            """Parse a string of Radiance gendaymtx data to a list of radiation-per-patch.
        
            This function handles the removing of the header and the conversion of the
            RGB irradianc-=per-steraidian values to broadband radiation. It also removes
            the first patch, which is the ground and is not used by Ladybug.
        
            Args:
                data_str: The string that has been output by gendaymtx to stdout.
                wea_duration: Number for the duration of the Wea in hours. This is used
                    to convert between the average value output by the command and the
                    cumulative value that is needed for all ladybug analyses.
                sky_density: Integer (either 1 or 2) for the density.
            """
            # split lines and remove the header, ground patch and last line break
            data_lines = data_str.split('\n')
            patch_lines = data_lines[9:-1]
        
            # loop through the rows and convert the radiation RGB values
            broadband_irr = []
            patch_counter = 0
            for i, row_patch_count in enumerate(PATCHES_PER_ROW[sky_density]):
                row_slice = patch_lines[patch_counter:patch_counter + row_patch_count]
                irr_vals = (broadband_radiation(row, i, wea_duration, sky_density)
                            for row in row_slice)
                broadband_irr.extend(irr_vals)
                patch_counter += row_patch_count
            return broadband_irr
        
        
        if all_required_inputs(ghenv.Component):
            # process and set defaults for all of the global inputs
            if north_ is not None:  # process the north_
                try:
                    north_ = math.degrees(
                        to_vector2d(north_).angle_clockwise(Vector2D(0, 1)))
                except AttributeError:  # north angle instead of vector
                    north_ = float(north_)
            else:
                north_ = 0
            density = 2 if high_density_ else 1
            ground_r = 0.2 if _ground_ref_ is None else _ground_ref_
        
            # filter the radiation by _hoys if they are input
            if len(_hoys_) != 0:
                _direct_rad = _direct_rad.filter_by_hoys(_hoys_)
                _diffuse_rad = _diffuse_rad.filter_by_hoys(_hoys_)
        
            # create the wea and write it to the default_epw_folder
            wea = Wea(_location, _direct_rad, _diffuse_rad)
            wea_duration = len(wea) / wea.timestep
            wea_folder = _folder_ if _folder_ is not None else \
                os.path.join(lb_folders.default_epw_folder, 'sky_matrices')
            metd = _direct_rad.header.metadata
            wea_basename = metd['city'].replace(' ', '_') if 'city' in metd else 'unnamed'
            wea_path = os.path.join(wea_folder, wea_basename)
            wea_file = wea.write(wea_path)
        
            # execute the Radiance gendaymtx command
            use_shell = True if os.name == 'nt' else False
            # command for direct patches
            cmds = [gendaymtx_exe, '-m', str(density), '-d', '-O1', '-A', wea_file]
            process = subprocess.Popen(cmds, stdout=subprocess.PIPE, shell=use_shell)
            stdout = process.communicate()
            dir_data_str = stdout[0]
            # command for diffuse patches
            cmds = [gendaymtx_exe, '-m', str(density), '-s', '-O1', '-A', wea_file]
            process = subprocess.Popen(cmds, stdout=subprocess.PIPE, shell=use_shell)
            stdout = process.communicate()
            diff_data_str = stdout[0]
        
            # parse the data into a single matrix
            dir_vals = parse_mtx_data(dir_data_str, wea_duration, density)
            diff_vals = parse_mtx_data(diff_data_str, wea_duration, density)
        
            # collect sky metadata like the north, which will be used by other components
            metadata = [north_, ground_r]
            if _hoys_:
                metadata.extend([DateTime.from_hoy(h) for h in (_hoys_[0], _hoys_[-1])])
            else:
                metadata.extend([wea.analysis_period.st_time, wea.analysis_period.end_time])
            for key, val in list(_direct_rad.header.metadata.items()):
                metadata.append('{} : {}'.format(key, val))
        
            # wrap everything together into an object to output from the component
            mtx_data = (metadata, dir_vals, diff_vals)
            sky_mtx = objectify_output('Cumulative Sky Matrix', mtx_data)
        

        for name in self.sv_output_names:
            if name in locals():
                getattr(self, '{}_out'.format(name)).append([locals()[name]])


def register():
    bpy.utils.register_class(SvSkyMatrix)

def unregister():
    bpy.utils.unregister_class(SvSkyMatrix)
