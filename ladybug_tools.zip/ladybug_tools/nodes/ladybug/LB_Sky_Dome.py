import bpy
import ladybug_tools.helper
from bpy.props import StringProperty
from sverchok.node_tree import SverchCustomTreeNode
from sverchok.data_structure import updateNode, zip_long_repeat

ghenv = ladybug_tools.helper.ghenv

class SvSkyDome(bpy.types.Node, SverchCustomTreeNode):
    bl_idname = 'SvSkyDome'
    bl_label = 'LB Sky Dome'
    sv_icon = 'LB_SKYDOME'
    sv__sky_mtx: StringProperty(name='_sky_mtx', update=updateNode, description='A Sky Matrix from the "LB Cumulative Sky Matrix" component, which describes the radiation coming from the various patches of the sky.')
    sv__center_pt_: StringProperty(name='_center_pt_', update=updateNode, description='A point for the center of the dome. (Default: (0, 0, 0))')
    sv__scale_: StringProperty(name='_scale_', update=updateNode, description='A number to set the scale of the sky dome. The default is 1, which corresponds to a radius of 100 meters in the current Rhino model\'s unit system.')
    sv_projection_: StringProperty(name='projection_', update=updateNode, description='Optional text for the name of a projection to use from the sky dome hemisphere to the 2D plane. If None, a 3D sky dome will be drawn instead of a 2D one. (Default: None) Choose from the following: * Orthographic * Stereographic')
    sv_show_comp_: StringProperty(name='show_comp_', update=updateNode, description='Boolean to indicate whether only one dome with total radiation should be displayed (False) or three domes with the solar radiation components (total, direct, and diffuse) should be shown. (Default: False).')
    sv_legend_par_: StringProperty(name='legend_par_', update=updateNode, description='An optional LegendParameter object to change the display of the sky dome (Default: None).')

    def sv_init(self, context):
        self.width *= 1.3
        input_node = self.inputs.new('SvLBSocket', '_sky_mtx')
        input_node.prop_name = 'sv__sky_mtx'
        input_node.tooltip = 'A Sky Matrix from the "LB Cumulative Sky Matrix" component, which describes the radiation coming from the various patches of the sky.'
        input_node = self.inputs.new('SvLBSocket', '_center_pt_')
        input_node.prop_name = 'sv__center_pt_'
        input_node.tooltip = 'A point for the center of the dome. (Default: (0, 0, 0))'
        input_node = self.inputs.new('SvLBSocket', '_scale_')
        input_node.prop_name = 'sv__scale_'
        input_node.tooltip = 'A number to set the scale of the sky dome. The default is 1, which corresponds to a radius of 100 meters in the current Rhino model\'s unit system.'
        input_node = self.inputs.new('SvLBSocket', 'projection_')
        input_node.prop_name = 'sv_projection_'
        input_node.tooltip = 'Optional text for the name of a projection to use from the sky dome hemisphere to the 2D plane. If None, a 3D sky dome will be drawn instead of a 2D one. (Default: None) Choose from the following: * Orthographic * Stereographic'
        input_node = self.inputs.new('SvLBSocket', 'show_comp_')
        input_node.prop_name = 'sv_show_comp_'
        input_node.tooltip = 'Boolean to indicate whether only one dome with total radiation should be displayed (False) or three domes with the solar radiation components (total, direct, and diffuse) should be shown. (Default: False).'
        input_node = self.inputs.new('SvLBSocket', 'legend_par_')
        input_node.prop_name = 'sv_legend_par_'
        input_node.tooltip = 'An optional LegendParameter object to change the display of the sky dome (Default: None).'
        output_node = self.outputs.new('SvLBSocket', 'mesh')
        output_node.tooltip = 'A colored mesh representing the intensity of radiation for each of the sky patches within the sky dome.'
        output_node = self.outputs.new('SvLBSocket', 'compass')
        output_node.tooltip = 'A set of circles, lines and text objects that mark the cardinal directions in relation to the sky dome.'
        output_node = self.outputs.new('SvLBSocket', 'legend')
        output_node.tooltip = 'A legend showing the kWh/m2 values that correspond to the colors of the mesh.'
        output_node = self.outputs.new('SvLBSocket', 'title')
        output_node.tooltip = 'A text object for the title of the sunpath.'
        output_node = self.outputs.new('SvLBSocket', 'patch_vecs')
        output_node.tooltip = 'A list of vectors for each of the patches of the sky dome. All vectors are unit vectors and point from the center towards each of the patches. They can be used to construct visualizations of the rays used to perform radiation analysis.'
        output_node = self.outputs.new('SvLBSocket', 'patch_values')
        output_node.tooltip = 'Radiation values for each of the sky patches in kWh/m2. This will be one list if show_comp_ is "False" and a list of 3 lists (aka. a Data Tree) for total, direct, diffuse if show_comp_ is "True".'
        output_node = self.outputs.new('SvLBSocket', 'mesh_values')
        output_node.tooltip = 'Radiation values for each face of the dome mesh in kWh/m2. This can be used to post-process the radiation data and then regenerate the dome visualization using the mesh output from this component and the "LB Spatial Heatmap" component. Examples of useful post- processing include converting the units to something other than kWh/m2, inverting the +/- sign of radiation values depending on whether radiation is helpful or harmful to building thermal loads, etc. This will be one list if show_comp_ is "False" and a list of 3 lists (aka. a Data Tree) for total, direct, diffuse if show_comp_ is "True".'

    def draw_buttons(self, context, layout):
        op = layout.operator('node.sv_lb_socket_name', text='', icon='QUESTION', emboss=False).tooltip = 'Visualize a sky matrix from the "LB Cumulative Sky Matrix" component as a colored dome, subdivided into patches with a radiation value for each patch. -'

    def process(self):
        if not any(socket.is_linked for socket in self.outputs):
            return

        self.sv_output_names = ['mesh', 'compass', 'legend', 'title', 'patch_vecs', 'patch_values', 'mesh_values']
        for name in self.sv_output_names:
            setattr(self, '{}_out'.format(name), [])
        self.sv_input_names = ['_sky_mtx', '_center_pt_', '_scale_', 'projection_', 'show_comp_', 'legend_par_']
        self.sv_input_types = ['System.Object', 'Point3d', 'double', 'string', 'bool', 'System.Object']
        self.sv_input_defaults = [None, None, None, None, None, None]
        self.sv_input_access = ['item', 'item', 'item', 'item', 'item', 'item']
        sv_inputs_nested = []
        for name in self.sv_input_names:
            sv_inputs_nested.append(self.inputs[name].sv_get())
        for sv_input_nested in zip_long_repeat(*sv_inputs_nested):
            for sv_input in zip_long_repeat(*sv_input_nested):
                sv_input = list(sv_input)
                for i, value in enumerate(sv_input):
                    if self.sv_input_access[i] == 'list':
                        if isinstance(value, (list, tuple)):
                            values = value
                        else:
                            values = [value]
                        value = [self.sv_cast(v, self.sv_input_types[i], self.sv_input_defaults[i]) for v in values]
                        if value == [None]:
                            value = []
                        sv_input[i] = value
                    else:
                        sv_input[i] = self.sv_cast(value, self.sv_input_types[i], self.sv_input_defaults[i])
                self.process_ladybug(*sv_input)
        for name in self.sv_output_names:
            value = getattr(self, '{}_out'.format(name))
            # Not sure if this hack is correct, will find out when more nodes are generated
            #if len(value) == 0 or not isinstance(value[0], (list, tuple)):
            #    value = [value]
            self.outputs[name].sv_set(value)

    def sv_cast(self, value, data_type, default):
        result = default if isinstance(value, str) and value == '' else value
        if result is None and data_type == 'bool':
            return False
        elif result is not None and data_type == 'bool':
            if result == 'True' or result == '1':
                return True
            elif result == 'False' or result == '0':
                return False
            return bool(result)
        elif result is not None and data_type == 'int':
            return int(result)
        elif result is not None and data_type == 'double':
            return float(result)
        return result

    def process_ladybug(self, _sky_mtx, _center_pt_, _scale_, projection_, show_comp_, legend_par_):

        import math
        
        try:
            from ladybug_geometry.geometry2d.pointvector import Point2D
            from ladybug_geometry.geometry3d.pointvector import Point3D, Vector3D
            from ladybug_geometry.geometry3d.mesh import Mesh3D
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug_geometry:\n\t{}'.format(e))
        
        try:
            from ladybug.viewsphere import view_sphere
            from ladybug.compass import Compass
            from ladybug.graphic import GraphicContainer
            from ladybug.legend import LegendParameters
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug:\n\t{}'.format(e))
        
        try:
            from ladybug_tools.config import conversion_to_meters
            from ladybug_tools.togeometry import to_point3d
            from ladybug_tools.fromgeometry import from_mesh3d, from_vector3d
            from ladybug_tools.fromobjects import legend_objects, compass_objects
            from ladybug_tools.text import text_objects
            from ladybug_tools.sverchok import all_required_inputs, \
                de_objectify_output, list_to_data_tree
        except ImportError as e:
            raise ImportError('\nFailed to import ladybug_tools:\n\t{}'.format(e))
        
        
        def draw_dome(dome_data, center, dome_name, legend_par):
            """Draw the dome mesh, compass, legend, and title for a sky dome.
        
            Args:
                dome_data: List of radiation values for the dome data
                center: Point3D for the center of the sun path.
                dome_name: Text for the dome name, which will appear in the title.
                legend_par: Legend parameters to be used for the dome
        
            Returns:
                dome_mesh: A colored mesh for the dome based on dome_data.
                dome_compass: A compass for the dome.
                dome_legend: A leend for the colored dome mesh.
                dome_title: A title for the dome.
                values: A list of radiation values that align with the dome_mesh faces.
            """
            # create the dome mesh and ensure patch values align with mesh faces
            if len(dome_data) == 145:  # tregenza sky
                lb_mesh = view_sphere.tregenza_dome_mesh_high_res.scale(radius)
                values = []  # high res dome has 3 x 3 faces per patch; we must convert
                tot_i = 0  # track the total number of patches converted
                for patch_i in view_sphere.TREGENZA_PATCHES_PER_ROW:
                    row_vals = []
                    for val in dome_data[tot_i:tot_i + patch_i]:
                        row_vals.extend([val] * 3)
                    for i in range(3):
                        values.extend(row_vals)
                    tot_i += patch_i
                values = values + [dome_data[-1]] * 18  # last patch has triangular faces
            else:  #reinhart sky
                lb_mesh = view_sphere.reinhart_dome_mesh.scale(radius)
                values = dome_data + [dome_data[-1]] * 11  # last patch has triangular faces
        
            # move and/or rotate the mesh as needed
            if north != 0:
                lb_mesh = lb_mesh.rotate_xy(math.radians(north), Point3D())
            if center != Point3D():
                lb_mesh = lb_mesh.move(Vector3D(center.x, center.y, center.z))
        
            # project the mesh if requested
            if projection_ is not None:
                if projection_.title() == 'Orthographic':
                    pts = (Compass.point3d_to_orthographic(pt) for pt in lb_mesh.vertices)
                elif projection_.title() == 'Stereographic':
                    pts = (Compass.point3d_to_stereographic(pt, radius, center)
                           for pt in lb_mesh.vertices)
                else:
                    raise ValueError(
                        'Projection type "{}" is not recognized.'.format(projection_))
                pts3d = tuple(Point3D(pt.x, pt.y, z) for pt in pts)
                lb_mesh = Mesh3D(pts3d, lb_mesh.faces)
        
            # output the dome visualization, including legend and compass
            move_fac = radius * 0.15
            min_pt = lb_mesh.min.move(Vector3D(-move_fac, -move_fac, 0))
            max_pt = lb_mesh.max.move(Vector3D(move_fac, move_fac, 0))
            graphic = GraphicContainer(values, min_pt, max_pt, legend_par)
            graphic.legend_parameters.title = 'kWh/m2'
            lb_mesh.colors = graphic.value_colors
            dome_mesh = from_mesh3d(lb_mesh)
            dome_legend = legend_objects(graphic.legend)
            dome_compass = compass_objects(
                Compass(radius, Point2D(center.x, center.y), north), z, None, projection_,
                graphic.legend_parameters.font)
        
            # construct a title from the metadata
            st, end = metadata[2], metadata[3]
            time_str = '{} - {}'.format(st, end) if st != end else st
            title_txt = '{} Radiation\n{}\n{}'.format(
                dome_name, time_str, '\n'.join([dat for dat in metadata[4:]]))
            dome_title = text_objects(title_txt, graphic.lower_title_location,
                                      graphic.legend_parameters.text_height,
                                      graphic.legend_parameters.font)
        
            return dome_mesh, dome_compass, dome_legend, dome_title, values
        
        
        if all_required_inputs(ghenv.Component):
            # set defaults for global variables
            _scale_ = 1 if _scale_ is None else _scale_
            radius = (100 * _scale_) / conversion_to_meters()
            if _center_pt_ is not None:  # process the center point into a Point2D
                center_pt3d = to_point3d(_center_pt_)
                z = center_pt3d.z
            else:
                center_pt3d, z = Point3D(), 0
        
            # deconstruct the sky matrix and derive key data from it
            metadata, direct, diffuse = de_objectify_output(_sky_mtx)
            north = metadata[0]  # first item is the north angle
            sky_type = 1 if len(direct) == 145 else 2  # i for tregenza; 2 for reinhart
            total = [dirr + difr for dirr, difr in zip(direct, diffuse)] # total radiation
        
            # override the legend default min and max to make sense for domes
            l_par = legend_par_.duplicate() if legend_par_ is not None else LegendParameters()
            if l_par.min is None:
                l_par.min = 0
            if l_par.max is None:
                l_par.max = max(total)
        
            # output patch patch vectors
            patch_vecs_lb = view_sphere.tregenza_dome_vectors if len(total) == 145 \
                else view_sphere.reinhart_dome_vectors
            patch_vecs = [from_vector3d(vec) for vec in patch_vecs_lb]
        
            # create the dome meshes
            if not show_comp_:  # only create the total dome mesh
                mesh, compass, legend, title, mesh_values = \
                    draw_dome(total, center_pt3d, 'Total', l_par)
                patch_values = total
            else:  # create domes for total, direct and diffuse
                # loop through the 3 radiation types and produce a dome
                mesh, compass, legend, title, mesh_values = [], [], [], [], []
                rad_types = ('Total', 'Direct', 'Diffuse')
                rad_data = (total, direct, diffuse)
                for dome_i in range(3):
                    cent_pt = Point3D(center_pt3d.x + radius * 3 * dome_i,
                                      center_pt3d.y, center_pt3d.z)
                    dome_mesh, dome_compass, dome_legend, dome_title, dome_values = \
                        draw_dome(rad_data[dome_i], cent_pt, rad_types[dome_i], l_par)
                    mesh.append(dome_mesh)
                    compass.extend(dome_compass)
                    legend.extend(dome_legend)
                    title.append(dome_title)
                    mesh_values.append(dome_values)
                patch_values = list_to_data_tree(rad_data)
                mesh_values = list_to_data_tree(mesh_values)
        

        for name in self.sv_output_names:
            if name in locals():
                getattr(self, '{}_out'.format(name)).append([locals()[name]])


def register():
    bpy.utils.register_class(SvSkyDome)

def unregister():
    bpy.utils.unregister_class(SvSkyDome)
