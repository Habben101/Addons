class Ghenv():
    pass

ghenv = Ghenv()
ghenv.Component = None
